Imagine Font
is created by jooki.de 2008 and redesigned in 2011
All rights reserved

Free for personal & uncommercial use!

For commercial use please purchase a license at:
http://new.myfonts.com/fonts/jooki/imagine-font 

This tiny and futuristic small cabs creation was done for my Game Project "ImagineEarth.info" A nice simple techno square font for headlines and styles! See it in action at:

greetings!
jooki.de
